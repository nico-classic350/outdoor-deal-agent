# Shop-source research policy

## Objective
Build the broadest practical EU retailer registry for the whitelist brands without inflating coverage with irrelevant, offline-only, duplicate-localized, or unverifiable shops.

## Active-source admission criteria
1. Legal/business seat in the EU.
2. Actual online ordering capability (not merely a store locator or physical shop page).
3. Ships to Germany, or offers relevant collection in Munich.
4. Evidence of at least one whitelisted brand or a sufficiently broad premium outdoor assortment where whitelist brands are directly verifiable.
5. Stable product/category URLs that can be crawled by feed/sitemap/JSON-LD/HTML/browser fallback.

## Discovery sources
- Brand dealer locators and retailer lists.
- Outdoor-industry directories.
- Trusted retailer/category directories.
- Search-engine discovery for whitelist brand + product family + sale/outlet.
- Existing retailer cross-sell/brand indexes.

## Ingestion priority
Feed/API > product sitemap > JSON-LD > HTML > browser automation > search-index fallback.

## Coverage rule
There is no fixed source-count target. Each run attempts all active relevant sources that are technically practical. The alert reports the exact measured coverage by status. Candidate sources are continuously validated and promoted into the active registry.

## Newly validated active sources added in this research pass
- Sport Förg (DE)
- Biwak Outdoor-Shop (DE)
- Feinbier unterwegs (DE)
- Biwakschachtel Tübingen (DE)
- Carl Denig (NL)
- Glisshop (FR)
- Outnorth (SE)

These augment the previously seeded German, Austrian, French, Spanish, Polish, Czech, Dutch, Belgian, Italian, Finnish and brand-direct EU sources.
