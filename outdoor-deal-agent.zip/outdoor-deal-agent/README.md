# Outdoor Deal Agent

A technical crawler/normalizer for EU outdoor shops. It does not send mail itself: `/api/run` returns normalized deals and a coverage report. ChatGPT/Gmail can format and send the alert.

## Pipeline
1. Registry: 200+ EU merchant sources.
2. Ingestion order: merchant feed/sitemap -> JSON-LD + HTML -> browser fallback.
3. Normalize product/variant, size, currency and merchant costs.
4. Hard brand whitelist, product-fit filter, size fit.
5. Convert non-EUR EU prices to EUR, add shipping/known return cost, calculate effective discount.
6. Deduplicate by brand/model/color.
7. Score 0-100 and return top deals plus near-miss candidates.
8. Persist run/source/product/offer history when DATABASE_URL is configured.

## Required production decisions
- Provision a Postgres-compatible database and set `DATABASE_URL` for persistent history.
- If browser-only merchants must be covered automatically, configure a browser execution backend. The code marks those merchants accurately until one is configured.

## Coverage semantics
A source is counted separately as `success`, `partial`, `browser`, `blocked`, or `failed`. A source that merely exists in the registry is never counted as successfully crawled.
