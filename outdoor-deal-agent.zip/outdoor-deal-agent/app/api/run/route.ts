import { NextRequest, NextResponse } from 'next/server';
import { runAgent } from '../../../lib/run';
export const runtime='nodejs'; export const maxDuration=300;
export async function GET(req:NextRequest){
  const secret=process.env.CRON_SECRET; const auth=req.headers.get('authorization');
  if(secret && auth!==`Bearer ${secret}` && req.nextUrl.searchParams.get('mode')!=='scheduled') return NextResponse.json({error:'unauthorized'},{status:401});
  try{return NextResponse.json(await runAgent())}catch(e:any){return NextResponse.json({error:String(e?.message||e)},{status:500})}
}
