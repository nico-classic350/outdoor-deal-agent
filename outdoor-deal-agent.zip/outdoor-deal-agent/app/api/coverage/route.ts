import { NextResponse } from 'next/server'; import { latestRun } from '../../../lib/store';
export async function GET(){return NextResponse.json({latest:await latestRun()})}
