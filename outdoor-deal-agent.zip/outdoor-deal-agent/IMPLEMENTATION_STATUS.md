# Implementation status

Implemented:
- Hard brand whitelist and product-fit profile.
- Source registry with country/priorities.
- Feed ingestion hook.
- Sitemap discovery.
- JSON-LD Product extraction.
- HTML fallback extraction.
- Chromium/Playwright browser fallback.
- EU-only merchant rule in configuration/pipeline contract.
- FX conversion to EUR (ECB daily rate, with safe fallback rates).
- Size-fit normalization for W33/W34 and L32 ceiling.
- Effective price/discount including shipping and known return costs.
- 0-100 deal score and alert classes.
- Product/offer deduplication.
- Qualified deals + near-miss fallback.
- Coverage statuses: success / partial / browser / blocked / failed.
- Optional Postgres persistence using DATABASE_URL.
- API endpoints `/api/run` and `/api/coverage`.
- Vercel Cron configuration.

Open production prerequisites:
1. New hosting target: the connected Vercel account currently exposes only an unrelated `immocheck-app`; this project has not been overwritten or deployed there.
2. Persistent DB: set DATABASE_URL to a Postgres-compatible store (Neon/Vercel Postgres recommended).
3. Registry growth: current verified seed registry is 84 sources. Target 200+ is enforced/reportable but should not be faked; additional verified EU shops need to be added.
4. Browser runtime: Playwright/Chromium fallback is coded, but production package installation/build still needs to complete in the deployment environment.
5. Gmail integration: keep Gmail delivery in ChatGPT automation initially; deployed crawler returns structured JSON + coverage report.

Validation performed:
- Unit arithmetic tests for effective discount passed.
- Source seed count validated at 84.
- Full npm install/build could not be completed in the current container because package installation timed out; no false deployment claim is made.


## Coverage policy update (2026-09-24)
- Removed the artificial 200+ hard threshold from runtime logic.
- Coverage is now quality-driven: crawl every validated relevant EU source in the active registry, discover additional sources, and report exact attempted/success/partial/browser/blocked/failed counts.
- A source is only active when it is an actual online shop, EU-based, ships to Germany (or is locally relevant in Munich), and has evidence of carrying at least one whitelisted brand/category.
- Candidate retailers remain outside active coverage until validated.
