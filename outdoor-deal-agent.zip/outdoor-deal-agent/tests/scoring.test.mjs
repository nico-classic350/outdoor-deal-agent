import test from 'node:test'; import assert from 'node:assert/strict';
test('effective discount arithmetic',()=>{const rrp=200,cost=120;assert.equal(Math.round((1-cost/rrp)*100),40)});
test('return costs reduce discount',()=>{const rrp=200,price=100,ship=5,ret=10;assert.equal(Math.round((1-(price+ship+ret)/rrp)*100),43)});
