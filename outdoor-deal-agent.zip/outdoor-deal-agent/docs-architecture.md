# Ingestion architecture

Per merchant source:
1. **Feed** when a feed URL is registered.
2. **Sitemap discovery** to obtain brand/category/product URLs.
3. **Structured extraction** from Product JSON-LD.
4. **HTML fallback** for classic server-rendered pages.
5. **Browser fallback** with Chromium/Playwright for JS-rendered pages or 403/429 pages where browser access succeeds.
6. Record exact outcome as success, partial, browser, blocked, or failed.

The pipeline never equates "present in registry" with "successfully crawled".
