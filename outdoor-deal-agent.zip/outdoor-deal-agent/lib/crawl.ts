import { ShopSource, RawOffer, SourceCoverage } from './types';
import { extractJsonLd, extractHtmlFallback } from './extract';
import { PROFILE } from '../config/profile';
import { ingestFeed } from './feed';
import { browserExtract } from './browser';

const UA='Mozilla/5.0 (compatible; OutdoorDealAgent/0.1; +https://example.invalid/bot)';
const BRAND_TERMS=PROFILE.brands.map(x=>x.toLowerCase().replace('adidas terrex','terrex'));

async function get(url:string, ms=10000){
  return fetch(url,{headers:{'user-agent':UA,'accept-language':'de-DE,de;q=0.9,en;q=0.5'},redirect:'follow',signal:AbortSignal.timeout(ms)});
}
function absolute(base:string,u:string){try{return new URL(u,base).toString()}catch{return ''}}

async function sitemapUrls(source:ShopSource):Promise<string[]> {
  const candidates = source.sitemapHints?.length ? source.sitemapHints.map(x=>absolute(source.baseUrl,x)) : [absolute(source.baseUrl,'/sitemap.xml'),absolute(source.baseUrl,'/sitemap_index.xml')];
  const urls:string[]=[];
  for(const sm of candidates){
    try{
      const r=await get(sm,8000); if(!r.ok) continue; const xml=await r.text();
      const locs=[...xml.matchAll(/<loc>(.*?)<\/loc>/g)].map(m=>m[1].replace(/&amp;/g,'&'));
      const nested=locs.filter(x=>/sitemap/i.test(x)).slice(0,20);
      if(nested.length){
        for(const n of nested){ try{const rr=await get(n,8000); if(!rr.ok) continue; const xx=await rr.text(); urls.push(...[...xx.matchAll(/<loc>(.*?)<\/loc>/g)].map(m=>m[1].replace(/&amp;/g,'&')))}catch{} }
      } else urls.push(...locs);
    }catch{}
  }
  const filtered=urls.filter(u=>{
    const s=u.toLowerCase(); return BRAND_TERMS.some(b=>s.includes(b.replace(/[^a-z0-9]/g,''))||s.includes(b)) || /(herren|men|pants|hose|hosen|trousers|outdoor|trekking|wandern|sale|outlet)/.test(s);
  });
  return [...new Set(filtered)].slice(0,120);
}

export async function crawlSource(source:ShopSource):Promise<{offers:RawOffer[],coverage:SourceCoverage}> {
  const start=Date.now(); let discovered:string[]=[]; const offers:RawOffer[]=[];
  try{
    const feedOffers=await ingestFeed(source);
    if(feedOffers.length) return {offers:feedOffers,coverage:{sourceId:source.id,name:source.name,status:'success',discoveredUrls:1,parsedOffers:feedOffers.length,elapsedMs:Date.now()-start,note:'feed'}};
    discovered=await sitemapUrls(source);
    if(!discovered.length) discovered=[source.baseUrl];
    for(const url of discovered.slice(0,60)){
      try{
        const r=await get(url,9000);
        if(r.status===403||r.status===429){
          const bx=await browserExtract(source,url); offers.push(...bx);
          return {offers,coverage:{sourceId:source.id,name:source.name,status:bx.length?'browser':'blocked',discoveredUrls:discovered.length,parsedOffers:offers.length,elapsedMs:Date.now()-start,note:bx.length?'browser fallback succeeded':`HTTP ${r.status}; browser fallback failed`}};
        }
        if(!r.ok) continue;
        const html=await r.text();
        let x=extractJsonLd(html,source,url);
        if(!x.length) x=extractHtmlFallback(html,source,url);
        offers.push(...x);
      }catch{}
    }
    if(!offers.length){
      const bx=await browserExtract(source,source.baseUrl); offers.push(...bx);
      const status=bx.length?'browser':'failed';
      return {offers,coverage:{sourceId:source.id,name:source.name,status,discoveredUrls:discovered.length,parsedOffers:offers.length,elapsedMs:Date.now()-start,note:bx.length?'browser fallback succeeded':'No parseable data after browser fallback'}};
    }
    const status = discovered.length>1?'success':'partial';
    return {offers,coverage:{sourceId:source.id,name:source.name,status,discoveredUrls:discovered.length,parsedOffers:offers.length,elapsedMs:Date.now()-start}};
  } catch(e:any){
    return {offers,coverage:{sourceId:source.id,name:source.name,status:'failed',discoveredUrls:discovered.length,parsedOffers:offers.length,elapsedMs:Date.now()-start,note:String(e?.message||e)}};
  }
}
