import * as cheerio from 'cheerio';
import { RawOffer, ShopSource } from './types';

function arr<T>(x:T|T[]|undefined|null):T[]{ return x==null?[]:Array.isArray(x)?x:[x]; }
function num(x:any):number|undefined { const n=Number(String(x??'').replace(/[^0-9.,]/g,'').replace(',','.')); return Number.isFinite(n)?n:undefined; }

export function extractJsonLd(html:string, source:ShopSource, url:string): RawOffer[] {
  const $=cheerio.load(html); const out:RawOffer[]=[];
  $('script[type="application/ld+json"]').each((_,el)=>{
    try {
      const parsed=JSON.parse($(el).text());
      const nodes=arr(parsed).flatMap((x:any)=>x?.['@graph']?x['@graph']:[x]);
      for(const p of nodes){
        if(!p || !String(p['@type']||'').toLowerCase().includes('product')) continue;
        const offers=arr(p.offers);
        for(const o of offers.length?offers:[{}]){
          out.push({
            sourceId:source.id, merchant:source.name, merchantCountry:source.country, url,
            imageUrl: arr(p.image)[0], brand: typeof p.brand==='string'?p.brand:p.brand?.name,
            name:p.name, color:p.color, description:p.description,
            sizes: arr(o.size || p.size).map(String), currency:o.priceCurrency,
            price:num(o.price || o.lowPrice), rrp:num(o.highPrice || p.msrp), availability:o.availability
          });
        }
      }
    } catch {}
  });
  return out;
}

export function extractHtmlFallback(html:string, source:ShopSource, url:string): RawOffer[] {
  const $=cheerio.load(html);
  const name=$('h1').first().text().trim() || $('meta[property="og:title"]').attr('content');
  const imageUrl=$('meta[property="og:image"]').attr('content');
  const description=$('meta[name="description"]').attr('content') || $('body').text().slice(0,5000);
  const priceText=$('[itemprop="price"]').attr('content') || $('[data-price]').first().attr('data-price') || $('.price,.product-price').first().text();
  const currency=$('[itemprop="priceCurrency"]').attr('content') || $('meta[property="product:price:currency"]').attr('content');
  const price=num(priceText);
  if(!name || !price) return [];
  return [{sourceId:source.id,merchant:source.name,merchantCountry:source.country,url,imageUrl,name,description,currency,price}];
}
