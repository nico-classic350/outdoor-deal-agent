import pLimit from 'p-limit';
import { SHOPS } from '../config/shops';
import { PROFILE } from '../config/profile';
import { crawlSource } from './crawl';
import { normalizeOffer } from './normalize';
import { NormalizedOffer, RunReport } from './types';
import { saveRun } from './store';

function key(o:NormalizedOffer){return `${o.brand}|${o.name}|${o.color||''}`.toLowerCase().replace(/\s+/g,' ')}
export async function runAgent(){
  const startedAt=new Date().toISOString(); const limit=pLimit(8);
  const results=await Promise.all(SHOPS.map(s=>limit(()=>crawlSource(s))));
  const raw=results.flatMap(r=>r.offers); const normalized=(await Promise.all(raw.map(normalizeOffer))).filter(Boolean) as NormalizedOffer[];
  const best=new Map<string,NormalizedOffer>();
  for(const o of normalized){const k=key(o), prev=best.get(k); if(!prev||o.effectiveCostEur<prev.effectiveCostEur) best.set(k,o)}
  const unique=[...best.values()].sort((a,b)=>b.score-a.score);
  const deals=unique.filter(x=>x.effectiveDiscountPct>=PROFILE.minEffectiveDiscountPct && x.class!=='Near Miss').slice(0,5);
  const near=unique.filter(x=>x.effectiveDiscountPct<PROFILE.minEffectiveDiscountPct && x.effectiveDiscountPct>=30).slice(0,3);
  const coverage=results.map(x=>x.coverage); const c=(s:string)=>coverage.filter(x=>x.status===s).length;
  const report:RunReport={startedAt,finishedAt:new Date().toISOString(),plannedSources:SHOPS.length,attemptedSources:coverage.length,success:c('success'),partial:c('partial'),browser:c('browser'),blocked:c('blocked'),failed:c('failed'),rawOffers:raw.length,normalizedOffers:normalized.length,qualifiedDeals:deals.length,nearMisses:near.length,coverage};
  await saveRun(report,deals,near);
  return {deals,nearMisses:near,report,registrySummary:{activeSources:SHOPS.length,attemptedSources:coverage.length,successfulSources:c('success')+c('partial')+c('browser'),blockedSources:c('blocked'),failedSources:c('failed')}};
}
