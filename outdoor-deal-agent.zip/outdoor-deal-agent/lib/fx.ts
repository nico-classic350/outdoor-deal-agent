const FALLBACK: Record<string, number> = { EUR:1, PLN:0.235, SEK:0.091, DKK:0.134, CZK:0.041, HUF:0.00256, RON:0.201 };
let cache: {at:number; rates:Record<string,number>}|null = null;

export async function eurValue(amount:number, currency:string): Promise<number> {
  const c = currency.toUpperCase();
  if (c === 'EUR') return amount;
  const rates = await loadRates();
  const r = rates[c] ?? FALLBACK[c];
  if (!r) throw new Error(`No FX rate for ${c}`);
  return amount * r;
}

export async function loadRates(): Promise<Record<string,number>> {
  if (cache && Date.now()-cache.at < 6*3600_000) return cache.rates;
  try {
    const res = await fetch('https://www.ecb.europa.eu/stats/eurofxref/eurofxref-daily.xml', {signal: AbortSignal.timeout(8000)});
    const xml = await res.text();
    const rates:Record<string,number> = {EUR:1};
    for (const m of xml.matchAll(/currency=['"]([A-Z]{3})['"]\s+rate=['"]([0-9.]+)['"]/g)) {
      rates[m[1]] = 1 / Number(m[2]);
    }
    cache = {at:Date.now(), rates};
    return rates;
  } catch {
    cache = {at:Date.now(), rates:FALLBACK};
    return FALLBACK;
  }
}
