import { PROFILE } from '../config/profile';

export function inferSizeFit(sizes:string[]|undefined): 'confirmed'|'probable'|'unconfirmed'|'no' {
  if (!sizes?.length) return 'unconfirmed';
  const norm = sizes.map(s=>s.trim().toUpperCase());
  const exact = norm.some(s => /(^|\D)(33|34)(\D|$)/.test(s) && (!/\/(\d+)/.test(s) || Number(s.match(/\/(\d+)/)?.[1]) <= PROFILE.inseamMax));
  if (exact) return 'confirmed';
  if (norm.some(s => ['L','EU 50','50','EU 52','52'].includes(s))) return 'probable';
  if (norm.some(s => /(^|\D)32(\D|$)/.test(s))) return 'no';
  return 'unconfirmed';
}
