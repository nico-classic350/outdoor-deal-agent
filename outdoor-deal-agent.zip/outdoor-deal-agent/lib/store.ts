import { neon } from '@neondatabase/serverless';
import { RunReport, NormalizedOffer } from './types';
export async function saveRun(report:RunReport,deals:NormalizedOffer[],near:NormalizedOffer[]){
  if(!process.env.DATABASE_URL) return;
  const sql=neon(process.env.DATABASE_URL);
  await sql`CREATE TABLE IF NOT EXISTS agent_runs(id bigserial primary key, started_at timestamptz, finished_at timestamptz, report jsonb, deals jsonb, near_misses jsonb)`;
  await sql`INSERT INTO agent_runs(started_at,finished_at,report,deals,near_misses) VALUES (${report.startedAt},${report.finishedAt},${JSON.stringify(report)}::jsonb,${JSON.stringify(deals)}::jsonb,${JSON.stringify(near)}::jsonb)`;
}
export async function latestRun(){
  if(!process.env.DATABASE_URL) return null;
  const sql=neon(process.env.DATABASE_URL);
  try { const rows=await sql`SELECT * FROM agent_runs ORDER BY id DESC LIMIT 1`; return rows[0]||null; } catch { return null; }
}
