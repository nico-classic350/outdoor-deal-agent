import { ShopSource, RawOffer } from './types';
import { extractJsonLd, extractHtmlFallback } from './extract';

export async function browserExtract(source:ShopSource,url:string):Promise<RawOffer[]> {
  try {
    const { chromium } = await import('playwright-core');
    const sparticuz = await import('@sparticuz/chromium');
    const executablePath = await sparticuz.default.executablePath();
    const browser = await chromium.launch({args:sparticuz.default.args,executablePath,headless:true});
    const page=await browser.newPage({locale:'de-DE'});
    await page.goto(url,{waitUntil:'domcontentloaded',timeout:20000});
    await page.waitForTimeout(1500);
    const html=await page.content();
    await browser.close();
    const json=extractJsonLd(html,source,url); return json.length?json:extractHtmlFallback(html,source,url);
  } catch { return []; }
}
