import { ShopSource, RawOffer } from './types';
function n(x:string|undefined){if(!x)return undefined; const y=Number(x.replace(/[^0-9.,]/g,'').replace(',','.'));return Number.isFinite(y)?y:undefined}
export async function ingestFeed(source:ShopSource):Promise<RawOffer[]> {
  if(!source.feedUrl) return [];
  try{
    const r=await fetch(source.feedUrl,{signal:AbortSignal.timeout(15000)}); if(!r.ok)return[]; const t=await r.text();
    if(t.trim().startsWith('[')||t.trim().startsWith('{')){
      const j=JSON.parse(t); const rows=Array.isArray(j)?j:(j.products||j.items||[]);
      return rows.map((p:any)=>({sourceId:source.id,merchant:source.name,merchantCountry:source.country,url:p.url||p.link,imageUrl:p.image||p.image_url,brand:p.brand,name:p.name||p.title,color:p.color,sizes:p.sizes||p.size,currency:p.currency||p.price_currency,price:Number(p.price),rrp:Number(p.rrp||p.msrp||p.original_price),shipping:Number(p.shipping||0),returnCost:p.return_cost==null?undefined:Number(p.return_cost),availability:p.availability,description:p.description})).filter((x:any)=>x.url&&x.name&&x.price);
    }
    const items=[...t.matchAll(/<(?:item|product)\b[\s\S]*?<\/(?:item|product)>/gi)].map(m=>m[0]);
    const tag=(s:string,k:string)=>s.match(new RegExp(`<${k}[^>]*>(?:<!\\[CDATA\\[)?([\\s\\S]*?)(?:\\]\\]>)?<\\/${k}>`,'i'))?.[1]?.trim();
    return items.map(s=>({sourceId:source.id,merchant:source.name,merchantCountry:source.country,url:tag(s,'link')||'',imageUrl:tag(s,'image_link'),brand:tag(s,'brand'),name:tag(s,'title'),color:tag(s,'color'),sizes:(tag(s,'size')||'').split(/[,|]/).filter(Boolean),currency:(tag(s,'price')||'').match(/[A-Z]{3}/)?.[0],price:n(tag(s,'sale_price')||tag(s,'price')),rrp:n(tag(s,'price')),description:tag(s,'description')})).filter(x=>x.url&&x.name&&x.price);
  }catch{return[]}
}
